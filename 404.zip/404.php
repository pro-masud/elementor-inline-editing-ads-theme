<section style="margin-top: 200px;" class="masonary-blog-section ">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 style="text-align: center; font-size: 50px; color: red;">
                    <?php _e("This Page Not Avalable Here. Try To Other Path Please?? ", 'freethemeads'); ?>
                </h1>
            </div>
        </div>
    </div>
</section>