<!-- page header section start -->
<section class="page-header position-relative overflow-hidden ptb-120 bg-dark" style="background: url('./images/page-header-bg.svg') no-repeat bottom left;">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12">
                <h1 class="display-5 fw-bold">Latest From Our Blog </h1>
                <p class="lead">Thoughts, ideas, tips and news fresh from our innovation lab  </p>
            </div>
        </div>
        <div class="bg-circle rounded-circle"></div>
    </div>
</section>
<!-- page header section end -->